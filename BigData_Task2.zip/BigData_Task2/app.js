const mongoose = require('mongoose');

// الاتصال بـ MongoDB (استخدمي اللي شغال عندك)
mongoose.connect('mongodb://localhost:27017/bigdata')
  .then(() => console.log('MongoDB Related Succesfully'))
  .catch(err => console.log('Connection Error', err));

// موديل المنتج
const productSchema = new mongoose.Schema({
  name: String,
  price: Number
});

const Product = mongoose.model('Product', productSchema);

// دالة لإضافة منتج
async function addProduct(name, price) {
  const product = new Product({ name, price });
  await product.save();
  console.log('Prodct Added', product);
}

// دالة لقراءة كل المنتجات
async function getAllProducts() {
  const products = await Product.find();
  console.log('Products List');
  console.log(products);
}

// دالة لتعديل منتج (بالـ ID)
async function updateProduct(id, newName, newPrice) {
  const product = await Product.findByIdAndUpdate(id, { name: newName, price: newPrice }, { new: true });
  console.log('Product Edited', product);
}

// دالة لحذف منتج (بالـ ID)
async function deleteProduct(id) {
  await Product.findByIdAndDelete(id);
  console.log('Product Deleted:', id);
}

// تشغيل العمليات بالترتيب
async function run() {
  // 1. إضافة منتجات جديدة
  await addProduct('Laptop', 35000);
  await addProduct('Mobile', 15000);
  await addProduct('HeadPhone', 2000);

  // 2. عرض كل المنتجات
  await getAllProducts();

  // 3. تعديل منتج (غيري الـ ID 
   await updateProduct('675e123456789abcde123456', 'لاب توب جديد', 40000);

  // 4. حذف منتج
   await deleteProduct('675e123456789abcde123456');

  // إغلاق الاتصال
  mongoose.connection.close();
  console.log('Connection Ended');
}

async function getAllProducts() {
  const products = await Product.find();
  console.log('Products List :');
products.forEach(p => {
  console.log('-Name : ' + p.name + ', Price: ' + p.price + ', ID: ' + p._id);
});
}
// شغلي الدالة الرئيسية
run();